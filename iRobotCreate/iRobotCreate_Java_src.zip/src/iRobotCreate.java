/**
 * @author joseph
 * @date 10/23/2008
 */
public class iRobotCreate {

	/**
	 * @param args
	 */
	static ControlPanel cp = new ControlPanel();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			cp.createAndShowGUI();
	}

}
